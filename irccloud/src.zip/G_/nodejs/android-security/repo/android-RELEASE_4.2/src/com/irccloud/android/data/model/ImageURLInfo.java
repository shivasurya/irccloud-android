package com.irccloud.android.data.model;

public class ImageURLInfo {
    public String thumbnail;
    public String mp4;
    public String title;
    public String description;
    public String original_url;
}
